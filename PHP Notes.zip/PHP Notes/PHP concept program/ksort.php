<?php
$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'teja',6=>'ashish',3=>'jyotsna');

ksort($p);//Sort array by keys in ascending order

var_dump($p);

?>