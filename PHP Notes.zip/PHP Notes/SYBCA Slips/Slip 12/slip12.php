<?php
$num=$_POST['n'];
 $result=factorial($num);
 echo "Factorial of $num is: $result";
function factorial($num) 
{
    if ($num < 0) 
    {
        return "Factorial is not defined for negative numbers.";
    }

    if ($num == 0 || $num == 1) 
    {
        return 1;
    }

    $fact = 1;
    for ($i = 2; $i <= $num; $i++) 
    {
        $fact *= $i;
    }

    return $fact;
}
?>

