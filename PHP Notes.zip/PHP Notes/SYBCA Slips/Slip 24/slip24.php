<?php

$name =$_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];

if(empty($name)  || !preg_match("/^[a-zA-Z ]+$/", $name))          
{
    echo "valid Name is required<br>";
}

elseif(!filter_var($email, FILTER_VALIDATE_EMAIL))
{
    echo "Invalid Email Address<br>";
}

elseif(!filter_var($age, FILTER_VALIDATE_INT) || $age >= 80 )     
{
    echo "Invalid Age<br>";
}

else
{
    echo "User Details:<br>";
    echo "Name: " . $name . "<br>";
    echo "Email: " . $email . "<br>";
    echo "Age: " . $age;
}

?>