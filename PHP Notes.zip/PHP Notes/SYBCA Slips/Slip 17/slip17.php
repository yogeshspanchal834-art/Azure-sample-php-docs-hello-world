<?php
    $s1 = $_POST['s1'];
    $s2 = $_POST['s2'];
    $num  = $_POST['num'];

    echo "<h3>Results:$s1 $s2</h3>";
switch($_POST['r'])
{
case 1:    if(strcmp($s1, $s2)==0)
		    echo "Strings are same";
		elseif(strcmp($s1, $s2)<0)
			echo "$s2 is greater";
		else
			echo "$s1 is greater";
break;
case 2:
    if(strncmp($s1, $s2,$num)==0)
		    echo "Strings are same";
		elseif(strncmp($s1, $s2,$num)<0)
			echo "$s2 is greater";
		else
			echo "$s1 is greater";

break;
case 3:
    if(strcasecmp($s1, $s2)==0)
		    echo "Strings are same";
		elseif(strcasecmp($s1, $s2)<0)
			echo "$s2 is greater";
		else
			echo "$s1 is greater";

break;

   }
?>

</body>
</html>