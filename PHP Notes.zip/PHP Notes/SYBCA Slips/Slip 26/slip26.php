<?php
function DisplayDay()
{
echo "Date:".date("d m y");
    $day = date("l");
    echo "<br>Today is: " . $day;
    $day = date("D");
    echo "<br>Today is: " . $day;

}

DisplayDay();
?>