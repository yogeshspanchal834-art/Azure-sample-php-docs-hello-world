<?php

$con=mysqli_connect("localhost","root","");

if (!$con)
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
$db=mysqli_query($con,"create database bca");
mysqli_select_db($con,"bca");

$q=mysqli_query($con,"create table product(pno int primary key,pname varchar(10),price int)");
 
if($q)

echo"\n\n Teble created Successfully\n";
           

$q=mysqli_query($con,"INSERT INTO product VALUES (1,'mouse',100)");
$q=mysqli_query($con,"INSERT INTO product VALUES (2,'CPU',1000)");
$q=mysqli_query($con,"INSERT INTO product VALUES (3,'printer',6000)");

$pno=$_GET['pno'];
$price=$_GET['bal'];

$q1=mysqli_query($con,"update product set pno=$pno,price='$price' where pno=$pno");
echo "updated successfully";

$q1=mysqli_query($con,"select * from product");

echo "<table border=1>";

echo "<tr><td>Product no.</td><td>Product Name</td><td>Price</td></tr>";



while($row=mysqli_fetch_array($q1))

{
	
	echo "<tr><td>".$row['pno']."</td><td>".$row['pname']."</td><td>".$row['price']."</td></tr>";

}

echo "</table>";

mysqli_close($con);
}
?>


