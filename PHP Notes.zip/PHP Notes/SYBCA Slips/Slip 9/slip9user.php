<html>
<head>
    <title>Array Operations</title>
</head>
<body>

<h2>Enter numbers separated by commas:</h2>

<form method="post">
    <input type="text" name="numbers" placeholder="e.g. 10,-5,20,-8,15" required>
    <input type="submit" name="submit" value="Submit">
</form>

<?php
if (isset($_POST['submit'])) {

    // Get user input
    $input = $_POST['numbers'];

    // Convert string to array
    $numbers = explode(",", $input);

    $sum = 0;
    $count = count($numbers);

    echo "<h3>Results:</h3>";

    foreach ($numbers as $num) {
        $num = trim($num);  // Remove extra spaces

        if (is_numeric($num)) {

            if ($num > 0) {
                echo "$num is Positive<br>";
            } elseif ($num < 0) {
                echo "$num is Negative<br>";
            } else {
                echo "$num is Zero<br>";
            }

            $sum += $num;
        } else {
            echo "$num is not a valid number<br>";
        }
    }

    if ($count > 0) {
        $average = $sum / $count;
        echo "<br><b>Sum:</b> $sum <br>";
        echo "<b>Average:</b> $average";
    }
}
?>

</body>
</html>