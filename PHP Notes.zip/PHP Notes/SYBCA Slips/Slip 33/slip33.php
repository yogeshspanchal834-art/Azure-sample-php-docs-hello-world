<?php

$con=mysqli_connect("localhost","root","");

if (!$con)
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
$db=mysqli_query($con,"create database bca");
mysqli_select_db($con,"bca");

$q=mysqli_query($con,"create table student(sno int primary key,sname varchar(10),per float,city varchar(10) )");
 
if($q)

echo"\n\n Table created Successfully\n";
           

$q=mysqli_query($con,"INSERT INTO student VALUES(101,'ABC',70.8,'pune')");
$q=mysqli_query($con,"INSERT INTO student VALUES(102,'PQR',87.8,'mumbai')");
$q=mysqli_query($con,"INSERT INTO student VALUES(103,'MNO',67.8,'satara')");


$q1=mysqli_query($con,"select * from student");

echo "<table border=1>";

echo "<tr><td>Roll No.</td><td>Name</td><td>Percentage</td><td>City</td></tr>";



while($row=mysqli_fetch_array($q1))

{
	
	echo "<tr><td>".$row['sno']."</td><td>".$row['sname']."</td><td>".$row['per']."</td><td>".$row['city']."</td></tr>";

}

echo "</table>";

mysqli_close($con);
}
?>


