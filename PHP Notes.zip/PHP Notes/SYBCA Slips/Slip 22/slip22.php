<?php

$s1 = $_GET['s1'];
$s2 = $_GET['s2'];


switch($_GET['o'])
{
    case 1:
        if($s1 == $s2)
            echo "Strings are equal using == operator.";
        else
            echo "Strings are NOT equal using == operator.";
        break;

    case 2:
        if(strcmp($s1, $s2) == 0)
            echo "Strings are equal using strcmp() function.";
        else
            echo "Strings are NOT equal using strcmp() function.";
        break;

    case 3:
        $result = $s1 . $s2;
        echo "Concatenated String: " . $result;
        break;

    case 4:
        $result = strrev($s1);
        echo "Reverse of First String: " . $result;
        break;
}

?>
