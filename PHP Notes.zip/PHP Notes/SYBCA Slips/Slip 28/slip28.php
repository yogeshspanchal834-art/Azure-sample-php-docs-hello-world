<?php

$ano=$_GET['ano'];

$atype=$_GET['atype'];

$bal=$_GET['bal'];


$con=mysqli_connect("localhost","root","");   
		if(!$con)
		{
			die('could not connect to database'.sql_error());
		}
		else
		{
		$db=mysqli_query($con,"create database login_db");
            	mysqli_select_db($con,"login_db");
	  	$sql1="create table account(ano int PRIMARY KEY, atype VARCHAR(15), bal INT)";
		$queryresult=mysqli_query($con,$sql1);

		
}

$q=mysqli_query($con,"INSERT INTO account (ano,atype,bal) VALUES ($ano,'$atype',$bal)");

if($q)
{
echo"\n\n Insertion Successfully\n";
}
else
{
echo"\n\n Duplicate Entry\n";
}
$q1=mysqli_query($con,"select * from account");

echo "<table border=1>";

echo "<tr><td>Account no.</td><td>Account Type</td><td>Balance</td></tr>";


if(! $q1 )
{
die('Could not get data: ' . mysql_error());
}
while($row=mysqli_fetch_array($q1))

{
	
	echo "<tr><td>".$row['ano']."</td><td>".$row['atype']."</td><td>".$row['bal']."</td></tr>";

}

echo "</table>";


mysqli_close($con);

?>
