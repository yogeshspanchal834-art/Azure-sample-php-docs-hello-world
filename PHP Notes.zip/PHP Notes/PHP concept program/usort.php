<?php

function my_sort($a,$b)
{
if ($a==$b)
 return 0;
return ($a<$b)?-1:1;
}

$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'tejashri',6=>'ashish',3=>'nadaf');
usort($p,"my_sort");

/*The function my_sort itself doesn't do the sorting.
 It just tells usort if a value is smaller, equal or greater than another value.
usort() uses an implementation of Quicksort to sort the array
 E.g. if $a = 5 and $b = 9 it will return 1 to indicate that
 the value in $b is greater than the one in $a.

Sorting is done by usort.
If a = b, return 0
If a > b, return 1
If a < b, return -1*/
var_dump($p);

?>