<?php

$arr1 = array(2,4,6,8,10,3,5);
$arr2 = array(1,2,3,4,9);

echo "Array1: ";
print_r($arr1);
echo "<br>";

echo "Array2: ";
print_r($arr2);
echo "<br><br>";

switch($_POST['o'])
{
case 1: 
	$union = array_unique(array_merge($arr1,$arr2));
	$intersection = array_intersect($arr1,$arr2);
	$difference = array_diff($arr1,$arr2);

	echo "<b>Union:</b> ";
	print_r($union);
	echo "<br>";

	echo "<b>Intersection:</b> ";
	print_r($intersection);
	echo "<br>";

	echo "<b>Difference:</b> ";
	print_r($difference);

	break;
case 2: 
        echo "<b>Array after removing odd numbers:</b> ";
	$even = array_filter($arr1,function($num) 
	{
		return $num % 2 == 0;
	});
	print_r($even);

	break;
case 3: 
	$names = array("A","B","C","D");
	$marks = array(70,85,60,90);

	array_multisort($names,$marks);

	echo "<b>Sorted Marks:</b> ";
	print_r($marks);
	echo "<br>";
	echo "<b>Names arranged accordingly:</b> ";
	print_r($names);
	break;

}

?>