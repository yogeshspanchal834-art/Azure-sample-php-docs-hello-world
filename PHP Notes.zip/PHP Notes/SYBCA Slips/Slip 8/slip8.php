<?php

  $s=$_POST['S']; 
echo "Given String is $s<br>";
$a=0;$e=0;$i=0;$o=0;$u=0;
    for ($t = 0; $t < strlen($s); $t++) 
{
      
        if ($s[$t]=='a')
       {
            $a++;
        }
if ($s[$t]=='e')
       {
            $e++;
        }
if ($s[$t]=='i')
       {
            $i++;
        }

if ($s[$t]=='o')
       {
            $o++;
        }

if ($s[$t]=='u')
       {
            $u++;
        }
}

   
    echo "Occurrences of each vowel:<br>";

   echo "<br>a occurs $a times" ;
   echo "<br>e occurs $e times" ;
   echo "<br>i occurs $i times" ;
   echo "<br>o occurs $o times" ;
   echo "<br>u occurs $u times" ;


?>