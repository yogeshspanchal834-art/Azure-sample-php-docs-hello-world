<?php
 $n1 = $_POST['n1'];
 $n2 = $_POST['n2'];

    echo "Original Values:";
    echo "A = $n1 , B = $n2 <br>";

 swapByValue($n1, $n2);
function swapByValue($a, $b) 
{
    $temp = $a;
    $a = $b;
    $b = $temp;
    echo "<h3>Inside swapByValue Function:</h3>";
    echo "After Swapping: A = $a , B = $b <br>";
}
    echo "<h3>After swapByValue Call (Outside Function):</h3>";
    echo "A = $n1 , B = $n2 <br>";

    swapByReference($n1, $n2);
function swapByReference(&$a, &$b) 
{
    $temp = $a;
    $a = $b;
    $b = $temp;
    echo "<h3>Inside swapByReference Function:</h3>";
    echo "After Swapping: A=$a , B =$b <br>";
}

    echo "<h3>After swapByReference Call (Outside Function):</h3>";
    echo "A = $n1 , B = $n2 <br>";

?>

