<?php
function my_sort($a,$b)
{
if ($a==$b) return 0;
return ($a<$b)?-1:1;
}

$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'teja',6=>'ashish',3=>'nadaf');
uksort($p,"my_sort");
print_r($p);
?>