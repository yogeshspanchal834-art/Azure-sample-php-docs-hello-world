<?php
function array_union($a, $b) {
  $union = array_merge($a, $b); // duplicates may still exist
  $union = array_unique($union);

  return $union;
}

$first = array(1, 'two', 3);
$second = array('two', 'three', 'four');
$union = array_union($first, $second);
print_r($union);
?>