<?php
function print_row($value, $key, $color) {
  print("<tr><td><font color=$color>$value</font></td><td bgcolor=$color>$key</td></tr>\n");
}
$person = array('name' => 'Fred', 'age' => 35, 'wife' => 'Wilma');
array_walk($person, 'print_row', 'blue');

?>