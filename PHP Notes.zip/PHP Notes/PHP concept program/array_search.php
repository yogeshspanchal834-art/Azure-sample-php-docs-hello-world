<?php
$p= array(1,2,3,4,5,6);
if(array_search(2,$p))
{
echo "in array";
}
else
{
echo "not in array";
}

?>