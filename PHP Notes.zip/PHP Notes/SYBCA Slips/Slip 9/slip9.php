<?php
$numbers = array(10, -5, 20, -8, 15, 0);

$sum = 0;
$count = count($numbers);

echo "<h3>Check whether elements are Positive or Negative:</h3>";

foreach ($numbers as $num) {
    if ($num > 0) {
        echo "$num is Positive<br>";
    } elseif ($num < 0) {
        echo "$num is Negative<br>";
    } else {
        echo "$num is Zero<br>";
    }
    
    // Add to sum
    $sum += $num;
}

if ($count > 0) {
    $average = $sum / $count;
} else {
    $average = 0;
}

echo "<h3>Sum of array elements: $sum</h3>";
echo "<h3>Average of array elements: $average</h3>";
?>