<?php
$a = 100;      
$b = "100";    


echo "Comparing using == (Equal Operator)<br>";
if ($a == $b) 
{
    echo "$a and $b are Equal<br>";
} else 
{
    echo "$a and $b are Not Equal<br>";
}

echo "Comparing using === (Identical Operator)<br>";
if ($a === $b) 
{
    echo "$a and $b are Identical<br>";
} else 
{
    echo "$a and $b are Not Identical<br>";
}

echo "Data Types";
echo "$a is of type: " . gettype($a) . "<br>";
echo "$b is of type: " . gettype($b) . "<br>";
?>