<?php
    $mobile = $_POST['mobile'];

   if (preg_match("/^[0-9]{10}$/", $mobile))
    {
        echo "Valid Mobile Number";
    } 
    else {
        echo "Invalid Mobile Number. Please enter a 10-digit number.";
    }
//^-Start of string 
//[0-9]-Only digits allowed 
//{10}-Exactly 10 digits 
//$-End of string

?>
