<?php
$a1=array("Dog","Cat");
$a2=array("Fido","Missy");
array_multisort($a1,$a2,SORT_ASC);//first in asc remaining are desc,
			   //if want to change sorting type add SORT_ASC
				//or SORT_DESC
print_r($a1);
print_r($a2);

?>

