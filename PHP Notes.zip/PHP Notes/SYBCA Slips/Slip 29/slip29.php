<!DOCTYPE html>
<html>
<head>
    <title>Bill</title>
</head>
<body>

<?php
if (isset($_GET['submit'])) {

    $codes = explode(";", $_GET['codes']);
    $names = explode(";", $_GET['names']);
    $units = explode(";", $_GET['units']);
    $rates = explode(";", $_GET['rates']);

    $count = count($codes);
    $grandTotal = 0;

    echo "<table border='1' cellpadding='5'>";
    echo "<caption><b>Bill</b></caption>";
    echo "<tr>
            <th>Item Code</th>
            <th>Item Name</th>
            <th>Units Sold</th>
            <th>Rate</th>
            <th>Total</th>
          </tr>";

    for ($i = 0; $i < $count; $i++) {

        $code = trim($codes[$i]);
        $name = trim($names[$i]);
        $unit = (int) trim($units[$i]);
        $rate = (float) trim($rates[$i]);

        $total = $unit * $rate;
        $grandTotal += $total;

        echo "<tr>
                <td>$code</td>
                <td>$name</td>
                <td>$unit</td>
                <td>$rate</td>
                <td>$total</td>
              </tr>";
    }

    echo "<tr>
            <td colspan='4'><b>Grand Total</b></td>
            <td><b>$grandTotal</b></td>
          </tr>";

    echo "</table>";
}
?>

</body>
</html>
