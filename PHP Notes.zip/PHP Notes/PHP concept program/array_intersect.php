<?php
$first = array(1, 'two', 3);
$second = array('two', 'three', 'four');
$u= array_intersect($first, $second);
print_r($u);
?>