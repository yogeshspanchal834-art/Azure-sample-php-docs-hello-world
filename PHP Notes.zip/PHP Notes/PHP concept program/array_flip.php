<?php

$ages  = array('roll'=>1,'name'=>'ghgj','class'=>'tybca');

$a=array_flip($ages);

print_r($a);

?>