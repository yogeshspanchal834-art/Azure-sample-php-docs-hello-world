<?php
$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'tejashri',6=>'ashish',3=>'nadaf');

asort($p);//Sort array by values in ascending order

var_dump($p);

?>