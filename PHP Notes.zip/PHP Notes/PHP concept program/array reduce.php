<?php
function add_up($running_total, $current_value) 
{
   $running_total += $current_value;
  return $running_total;
}

$numbers = array(2, 3, 5, 7);
$total = array_reduce($numbers,'add_up');
echo "Sum of array is: $total";
?>