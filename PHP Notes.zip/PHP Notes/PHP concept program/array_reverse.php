<?php

$ages  = array(25,35,29,35,35);

$a=array_reverse($ages);

print_r($a);

?>