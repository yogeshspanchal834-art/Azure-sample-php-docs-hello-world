<?php
$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'tejashri',6=>'ashish',3=>'nadaf');

rsort($p);//Sort array by values, then reassign indexes starting with 0 in Descending order
var_dump($p);

?>