<?php
$p= array(5=>'vishal',2=>'sumit',1=>'shubhangi',4=>'teja',6=>'ashish',3=>'jyotsna');

arsort($p);//Sort array by values in Descending order

var_dump($p);

?>