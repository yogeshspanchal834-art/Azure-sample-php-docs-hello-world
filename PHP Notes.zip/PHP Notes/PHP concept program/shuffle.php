<?php

$days = array('Monday', 'Tuesday', 'Wednesday',
  'Thursday', 'Friday', 'Saturday', 'Sunday');
shuffle($days);
print_r($days);


?>