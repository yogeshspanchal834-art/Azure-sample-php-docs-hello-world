<?php
$p=array(1,2,3,4,5,6);
if(in_array(2,$p))
{
echo "in array";
}
else
{
echo "not in array";
}
?>