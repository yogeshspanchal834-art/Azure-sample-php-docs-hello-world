<?php

$c = $_POST['cname'];
$p = $_POST['products'];   // laptop   keyboard
$qty = $_POST['qty'];

$rates = array("Laptop" => 50000,"Mobile" => 20000,"Headphones" => 2000,"Keyboard" => 1000);

$totalbill = 0;

echo "<h2>Customer Bill</h2>";
echo "Customer Name: <b>$c</b><br><br>";

echo "<table border=1>";

echo "<tr>
        <th>Product</th>
        <th>Rate</th>
        <th>Quantity</th>
        <th>Total</th>
      </tr>";

foreach($p as $k)
{
    $rate = $rates[$k];     //$rates[laptop]   50000
    $quantity = $qty[$k];    //$qty[qty[Laptop]]    2
    $total = $rate * $quantity;     //50000*2

    $totalbill += $total;

    echo "<tr>
            <td>$k</td>
            <td>$rate</td>
            <td>$quantity</td>
            <td>$total</td>
          </tr>";
}

echo "<tr>
        <td colspan=3><b>Grand Total</b></td>
        <td><b>$totalbill</b></td>
      </tr>";

echo "</table>";

?>