<?php

function print_row($value, $key) 
{
  print("<tr><td>$key </td><td> $value</td></tr><br>\n");
}

$person = array('ROll' => 1, 'name' => 'xyz', 'class' => 'TYBCA');

array_walk($person, 'print_row');
?>