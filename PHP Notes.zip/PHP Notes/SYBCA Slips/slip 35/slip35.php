<?php

$con=mysqli_connect("localhost","root","","bca");

if (!$con)
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{

$q=mysqli_query($con,"create table bus(bno int primary key,bname varchar(10),src varchar(20),dest varchar(20))");
 
if($q)

echo"\n\n Teble created Successfully\n";
           

$q=mysqli_query($con,"INSERT INTO bus VALUES (1,'Shivneri','Pune','Mumbai')");
$q=mysqli_query($con,"INSERT INTO bus VALUES (2,'Shivshahi','Nashik','Mumbai')");
$q=mysqli_query($con,"INSERT INTO bus VALUES (3,'Lalpari','Pune','Nashik')");
$q=mysqli_query($con,"INSERT INTO bus VALUES (4,'Hirkani','Satara','Nashik')");

$busName = $_POST['bname'];

$query = "select * from bus where bname = '$busName'";

$ret_val = mysqli_query($con, $query);

$record = mysqli_fetch_row($ret_val);

echo "<table border=1> <tr><th>BUS ID</th>
      <th> BUS NAME</th><th>SOURCE</th><th>DESTINATION</th></tr>";

echo "<tr><td>$record[0]</td>
          <td>$record[1]</td>
	      <td>$record[2]</td>
		  <td>$record[3]</td>
	  </tr></table>";

 
mysqli_close($con);

}
?>
