<?php

$main = $_POST['s'];
$sub  = $_POST['s1'];

echo "<h2>String Searching Results</h2>";

echo "Main String: " . $main . "<br>";
echo "Search String: " . $sub . "<br><br>";

echo "<b>Search String First Position in Main String(case-sensitive)-strpos()</b> : ";
echo strpos($main, $sub);
echo "<br>";

echo "<b>Search First String Position in Main String(case-insensitive)-stripos()</b> : ";
echo stripos($main, $sub);
echo "<br>";

echo "<b>Search String last occurrence Position in Main String (case-sensitive)-strrpos()</b> : ";
echo strrpos($main, $sub);
echo "<br>";

echo "<b>Search String last occurrence  Position in Main String (case-insensitive)-strripos()</b> : ";
echo strripos($main, $sub);
echo "<br>";

echo "<b>Search String Position in Main String (returns part of string from first match) (case-sensitive)-strrstr()</b> : ";
echo strstr($main, $sub);
echo "<br>";

echo "<b>Search String Position in Main String (returns part of string from first match) (case-insensitive strstr)-stristr()</b> : ";
echo stristr($main, $sub);
echo "<br>";

echo "<b>Search String Position in Main String (alias of strstr)-strchr()</b> : ";
echo strchr($main, $sub);
echo "<br>";

?>